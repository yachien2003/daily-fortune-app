package cgu.im.afinal;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
        TextView historyTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_history);

            historyTextView = findViewById(R.id.historyTextView);

            SharedPreferences prefs = getSharedPreferences("history", MODE_PRIVATE);
            String history = prefs.getString("history_list", "尚無紀錄");
            historyTextView.setText(history);
        }
    }