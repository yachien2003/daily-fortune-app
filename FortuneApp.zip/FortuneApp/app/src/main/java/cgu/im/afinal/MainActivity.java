package cgu.im.afinal;


import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerCategory;
    private ImageView imageWheel;
    private Button buttonSpin;
    private TextView textResult, textResult2;
    private Switch switchSound;

    private MediaPlayer mediaPlayer;
    private SeekBar seekBarSpeed;
    private int duration = 3000;
    private int lastAngle = 0;
    private final Random random = new Random();

    private final Map<String, String[]> fortunes = new HashMap<String, String[]>() {{
        put("愛情運勢", new String[]{
                "桃花旺盛，今日有機會遇見心動對象",
                "爛桃花纏身，請提高警覺，小心不懷好意的人",
                "魅力上升，專注自我成長會吸引對的人",
                "告白成功率高，勇敢表白也許能贏得對方芳心",
                "戀情升溫，與伴侶的相處愈發甜蜜和諧",
                "感情低潮，適合靜下心好好溝通與反思彼此需求",
                "戀愛運略差，戀愛中人感情困擾多，容易產生鬱悶或不甘心的情緒",
                "暗戀中的你今天有被注意到的機會，好好把握！",
                "散發出自信的魅力，特別能吸引異性目光"
        });
        put("事業運勢", new String[]{
                "事業如日中天，有升遷或表現機會，記得爭取！",
                "穩定中求進步，今日適合規劃未來的職涯藍圖",
                "遇貴人相助，困難會有出現解決方法的轉機",
                "容易與同事發生摩擦，建議保持冷靜與理性",
                "小人當道，處事需謹慎，避免過度曝光個人想法",
                "靈感湧現，創意十足，適合從事創作型任務",
                "容易分心拖延，專注力下降，需提高自律",
                "會議或簡報表現佳，領導對你印象深刻"
        });
        put("學業運勢", new String[]{
                "學習效率超高，適合攻克難題或準備大考",
                "考試運不錯，臨時抱佛腳也可能有意外收穫",
                "專注力較低，容易被外在環境干擾",
                "與同儕合作順利，團體報告能取得不錯成績。",
                "壓力山大但成果可期，撐下去會看見成果",
                "學習靈感強，適合發展新的學習方法或技巧",
                "今天適合複習而非新學習，吸收力較低"
        });
        put("手氣運勢", new String[]{
                "今天手氣超旺，買彩券可能中獎！",
                "有機會在抽獎活動中被選中",
                "玩遊戲必中好卡，運勢大開",
                "有小確幸，可能撿到好康",
                "運氣普通，不好不壞，順其自然",
                "抽獎擦身而過，再接再厲！",
                "今天手氣較差，建議低調",
                "手氣不佳，避免衝動消費或賭博"
        });
        put("人際運勢", new String[]{
                "有人會主動接近你，結識新朋友",
                "適合溝通協調，人際互動順利",
                "老朋友可能會聯絡你，驚喜重逢！",
                "今天說話有魅力，人見人愛",
                "人際普通，保持中立觀望",
                "容易有誤會或爭執，小心溝通",
                "有可能遇到冷場或尷尬場面",
                "今天不適合社交，建議低調行事"
        });
        put("財運", new String[]{
                "投資順利，有望小賺一筆",
                "財務耗損的日子，不是掉錢包，就是亂花錢",
                "在小錢上勿過於斤斤計較，小心淪為朋友眼中的小氣財神",
                "有人請客，財運小旺",
                "收支平衡，財運穩定",
                "支出略多，小心荷包失守",
                "有破財風險，謹慎處理財務",
                "財運低迷，建議暫緩投資與消費"
        });
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        imageWheel = findViewById(R.id.imageWheel);
        buttonSpin = findViewById(R.id.buttonSpin);
        textResult = findViewById(R.id.textResult);
        textResult2 = findViewById(R.id.textResult2);
        switchSound = findViewById(R.id.switchSound);
        seekBarSpeed = findViewById(R.id.seekBarSpeed);

        seekBarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                duration = 500 + (100 - progress) * 25;
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        switchSound.setChecked(true);
        mediaPlayer = MediaPlayer.create(this, R.raw.sound);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        switchSound.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mediaPlayer.start();
            } else {
                mediaPlayer.pause();
            }
        });

        buttonSpin.setOnClickListener(v -> {
            String selectedCategory = spinnerCategory.getSelectedItem().toString();
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            String key = selectedCategory + "_" + today;

            SharedPreferences prefs = getSharedPreferences("FortunePrefs", MODE_PRIVATE);
            if (prefs.contains(key)) {
                Toast.makeText(this, "今天的" + selectedCategory + "已經測試過囉！", Toast.LENGTH_SHORT).show();
            } else {
                spinWheel(selectedCategory);
                prefs.edit().putBoolean(key, true).apply();
            }
        });
    }

    private void spinWheel(String selectedCategory) {
        String[] selectedFortunes = fortunes.get(selectedCategory);
        int randomIndex = random.nextInt(selectedFortunes.length);
        String selectedFortune = selectedFortunes[randomIndex];

        int spinAngle = 360 * 2 + random.nextInt(360);
        RotateAnimation rotate = new RotateAnimation(
                lastAngle, lastAngle + spinAngle,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);

        rotate.setDuration(duration);
        rotate.setFillAfter(true);
        imageWheel.startAnimation(rotate);
        lastAngle = (lastAngle + spinAngle) % 360;

        rotate.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation animation) {}

            public void onAnimationEnd(Animation animation) {
                String result = selectedFortunes[randomIndex];
                textResult.setText("今天的" + selectedCategory + "...");
                textResult2.setText(result);

                SharedPreferences prefs = getSharedPreferences("history", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();

                String oldHistory = prefs.getString("history_list", "");
                String newItem = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(new Date())
                        + " - " + selectedCategory  + "\n" + result;

                String updatedHistory = newItem + "\n" + oldHistory;
                editor.putString("history_list", updatedHistory);
                editor.apply();
            }
            public void onAnimationRepeat(Animation animation) {}
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_history) {
            Intent intent = new Intent(this, HistoryActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}